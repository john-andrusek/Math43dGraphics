using Godot;
using System;



public class Cube : Navigation
{
    private float ticksPerRotation = 360 / 50.0f;

    private float ticksPerFrame = 150.0f;
    private float xRotation = 0.0f;
    private float yRotation = 0.0f; 
    private float zRotation = 0.0f;

    private float xScale = 1.0f;

    private float yScale = 1.0f;

    private float zScale = 1.0f;

    private string updateParam = "10";

    private Vector2 fpsTranslation;
   
    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
    {
        Vector2 screenSize = this.GetViewport().GetVisibleRect().Size;
        this.fpsTranslation = screenSize / this.ticksPerFrame;
    }

    public void updateDisplayParams(string id) {
       this.updateParam = id;
    }

    public void _on_rotationSlider_value_changed(float value) {
      this.xRotation = (value - 50) * this.ticksPerRotation;
    }

    public void _on_yRotatonSlider_value_changed(float value) {
        this.yRotation = (value - 50) * this.ticksPerRotation;
    }

    private float adjustScaleFactor(float val) {
        if (val >= 50) {
            return  1.0f;
        }
        return  val;
    }

    public void _on_yScaleCB_toggled(bool val) {
        if (val) {
            this.yScale = 2.0f;
        } else {
            this.yScale = 0.5f;
        }

       
    }

    public void _on_zScaleCB_toggled(bool val) {
        if (val) {
            this.zScale = 2.0f;
        } else {
            this.zScale = 0.5f;
        }

       
    }

    public void _on_xScaleCB_toggled(bool val) {
        if (val) {
            this.xScale = 2.0f;
        } else {
            this.xScale = 0.5f;
        }

       
    }

    public void _on_XScaleSlider_value_changed(float value) {
        this.xScale = this.adjustScaleFactor(value);
        GD.Print(this.xScale);
    }

    public void _on_zRotationSlider_value_changed(float value) {
        this.zRotation = (value - 50) * this.ticksPerRotation;
    }

   private void applyRotation(float deltaT) {
        this.RotateX(Mathf.Deg2Rad(this.xRotation * deltaT));
        this.RotateY(Mathf.Deg2Rad(this.yRotation * deltaT));   
        this.RotateZ(Mathf.Deg2Rad(this.zRotation * deltaT));
   }

   private Vector3 applyTransaltion(float deltaT) {
        Vector3 delta = new Vector3(0.0f,0.0f,0.0f);
        if (Input.IsKeyPressed((int)Godot.KeyList.Right)) {
            delta.x = this.fpsTranslation.x;
        } else if (Input.IsKeyPressed((int)Godot.KeyList.Left)) {
            delta.x = -this.fpsTranslation.x;
        } else if ((Input.IsKeyPressed((int)Godot.KeyList.Up)) && (Input.IsKeyPressed((int)Godot.KeyList.Shift))) {
            delta.z = this.fpsTranslation.y;
        } else if ((Input.IsKeyPressed((int)Godot.KeyList.Down)) && (Input.IsKeyPressed((int)Godot.KeyList.Shift))) {
            delta.z = -this.fpsTranslation.y;
        } else if (Input.IsKeyPressed((int)Godot.KeyList.Up)) {
            delta.y = this.fpsTranslation.y;
        } else if (Input.IsKeyPressed((int)Godot.KeyList.Down)) {
            delta.y = -this.fpsTranslation.y;
        } 
        //this.Translate(delta * deltaT); 
        //this.GlobalTranslate(delta * deltaT);
        
        Transform t = this.GetTransform();
        t.origin += new Vector3(delta * deltaT);
        this.SetTransform(t);
        return delta;
   }

    private void applyScale() {
        this.GlobalScale(new Vector3(this.xScale,this.yScale,this.zScale));
        this.xScale = 1.0f;
        this.yScale = 1.0f;
        this.zScale = 1.0f;
    }

   // Called every frame. 'delta' is the elapsed time since the previous frame.
   public override void _Process(float delta)
   {
        switch (this.updateParam)
        {
          case "0":
             break;
          case "1":
            this.applyRotation(delta);
            break;   
          case "2":
            this.applyTransaltion(delta);
            break;   
          case "3":
            this.applyScale();
            break;   
          case "4":
            this.applyTransaltion(delta);
            this.applyRotation(delta);
            break;   
          case "5":
            this.applyRotation(delta);
            this.applyTransaltion(delta);
            break;   
          case "6":
            this.applyTransaltion(delta);
            this.applyRotation(delta);
            this.applyScale();
            break; 
          case "7":
            this.applyTransaltion(delta);
            this.applyScale();
            this.applyRotation(delta);
            break; 
          case "8":
            this.applyRotation(delta);
            this.applyTransaltion(delta);
            this.applyScale();
            break;   
          case "9":
            this.applyRotation(delta);
            this.applyScale();
            this.applyTransaltion(delta);
            break;
          case "10":
            this.applyScale();
            this.applyRotation(delta);
            this.applyTransaltion(delta);
            break;
          case "11":
            this.applyScale();
            this.applyTransaltion(delta);
            this.applyRotation(delta);
            break;  
        }    
        
        

   }
}
